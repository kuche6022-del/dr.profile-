
const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('.main-nav');
if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});}
const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
const form=document.getElementById('contact-form');
if(form){form.addEventListener('submit',e=>{e.preventDefault();const note=document.getElementById('form-note');note.textContent='This form is not connected yet. Please add an approved email address or secure form service before launch.';});}
